'''
Before using this program, please install pip, bs4 and update your python
-------------------------------------------------------------
pip
if you don't have pip installed, run the following lines->
curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
python get-pip.py
-------------------------------------------------------------
bs4
if you don't have bs4, run the following (note: pip is a pre-requsite) ->
pip install bs4
'''

from bs4 import BeautifulSoup
import requests
import urllib2
import json


HEADER = {'User-Agent':"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36"}
# url= "http://yellowpages.in/hyderabad/restaurants/161059018" 
fileName = "hyderabad_restaurants"

def get_soup(url,header):
    return BeautifulSoup(urllib2.urlopen(urllib2.Request(url,headers=header)),'html.parser')


def performReq(fileName):
	dataList = []
	count = 0
	errorCount = 0
	# soup = get_soup(url, HEADER)
	with open(fileName + ".html") as fp:
		soup = BeautifulSoup(fp, 'html.parser')
	
	for a in soup.find_all("div",{"class":"eachPopular"}):
		try:
			dataImage = "Unknown"
			dataName = "Unknown"
			dataPhoneNumber = "Unknown"
			dataAddress = "Unknown"
			dataMapsLink = "Unknown"
			dataTags = []
			leftSide = a.find('div', {"class":'eachPopularLeft'})
			if(not(leftSide == None)):
				if(not(leftSide.find('div', {"class": "eachPopularImage"}) == None) and not(leftSide.find('div', {"class": "eachPopularImage"}).find("a") == None) and not(leftSide.find('div', {"class": "eachPopularImage"}).find("a").find("img") == None)):
							dataImage =  leftSide.find('div', {"class": "eachPopularImage"}).find("a").find("img").attrs["src"]
			titleArea = leftSide.find('div', {"class" : "eachPopularTitleBlock"})
			if(not(titleArea == None) and not(titleArea.find('div', {"class": "popularTitleTextBlock"}) == None) and not(titleArea.find('div', {"class": "popularTitleTextBlock"}).find('a') == None)):
				dataName = titleArea.find('div', {"class": "popularTitleTextBlock"}).find('a').text
				tagUl =  titleArea.find('ul', {"class": "eachPopularTagsList"})	
				if(not(tagUl == None)): 
					for t in tagUl.find_all('a'):
						dataTags.append(t.text)
			rightSide = a.find('div', {"class":'eachPopularRight'})
			if(not(rightSide == None)):
				if(not(rightSide.find('a') == None)):
					dataPhoneNumber = rightSide.find('a').text
				if(not(rightSide.find('address') == None)):
					dataAddress = rightSide.find('address').text
				if(not(rightSide.find('div', {"class":"directionsLocationsBlock"}) == None) and not(rightSide.find('div', {"class":"directionsLocationsBlock"}).find('a') == None)):
					mapBlock = rightSide.find('div', {"class":"directionsLocationsBlock"}).find('a')
					if(not(mapBlock == None)):
						dataMapsLink = mapBlock['href']
			print "\n\n------------------------------------------------------"
			print "Name: ", dataName
			print "Image: ", dataImage
			print "Address: ", dataAddress
			print "Tags: ", dataTags
			print "Maps: ", dataMapsLink
			item = {"name":dataName, "image": dataImage, "address":dataAddress, "tags":dataTags, "map_link":dataMapsLink}
			dataList.append(item)
		except:
			errorCount +=1
			print "error at index : ", count
		count +=1
		# link , Type =json.loads(a.text)["ou"]  ,json.loads(a.text)["ity"]
		# dataList.append((link,Type))
	print "-----------------------------------------------------------------"
	print "result count: ", count
	print "error count: ", errorCount
	return dataList

dataList = performReq(fileName)
# print dataList

data = {"data":dataList}
with open(fileName + '.json', 'w') as outfile: json.dump(data, outfile)

outfile.close()



'''
MIT License

Copyright (c) 2018 Vrushabh Jambhulkar

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
'''